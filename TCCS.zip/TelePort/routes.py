from TelePort import app
from flask import render_template
from TelePort.forms import loginEmployee, placeOrder, signUpManager, loginManager, signUpCustomer, \
    loginCustomer, createEmployee, createOffice,addTruck,viewBill, viewTruckStatus
from TelePort.models import Consignment, Customer, Manager, Employee, Office, Truck
from TelePort import db
from flask import Flask,flash, redirect, url_for,session
from flask_login import login_user, logout_user
from flask_session import Session

# app = Flask(__name__)
@app.route('/')
@app.route('/home')
def index():
    if 'manager' in session:
        session.pop('manager', None)
    if 'customer' in session:
        session.pop('customer', None)
    if 'employee' in session:
        session.pop('employee', None)
    if 'consignment' in session:
        session.pop('consignment', None)
    if 'office' in session:
        session.pop('office', None)
    if 'truck' in session:
        session.pop('truck', None)
    logout_user()
    session['name'] = ""
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/signup_manager', methods = ['GET', 'POST'])
def signup_manager():
    form = signUpManager()
    if form.validate_on_submit():
        manager = Manager(managerID = form.ID.data, name = form.Name.data, 
                          address = form.address.data, phoneNumber = form.phoneNumber.data, 
                          email = form.email.data, password = form.password1.data)
        db.session.add(manager)
        db.session.commit()
        if form.errors == {}:
            flash(f'Success! You are signed up as: {manager.name}', category='success')
        return redirect(url_for('login_manager'))
        
    if form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg, category='danger')
        
    return render_template('signup_manager.html', form = form)

@app.route('/login_manager', methods = ['GET', 'POST'])
def login_manager():
    form = loginManager()
    if form.validate_on_submit():
        attempted_manager = Manager.query.filter_by(email = form.email.data).first()
        
        if attempted_manager and attempted_manager.check_password_correction(form.password.data):
            session['manager'] = (attempted_manager)
            session['name'] = attempted_manager.name
            login_user(attempted_manager)
            flash(f'Success! You are logged in as: {attempted_manager.name}', category='success')
            # print(attempted_manager.name)
            return redirect(url_for('manager_actions2'))
        else:
            flash('Invalid email or password! Please try again', category='danger')
    return render_template('login_manager.html', form = form)

@app.route('/logout')
def logout_page():
    if 'manager' in session:
        session.pop('manager', None)
    if 'customer' in session:
        session.pop('customer', None)
    if 'employee' in session:
        session.pop('employee', None)
    if 'consignment' in session:
        session.pop('consignment', None)
    if 'office' in session:
        session.pop('office', None)
    if 'truck' in session:
        session.pop('truck', None)
    logout_user()
    flash("You have been logged out!", category='info')
    return redirect(url_for('index'))

@app.route('/login_employee', methods = ['GET', 'POST'])
def login_employee():
    form = loginEmployee()
    if form.validate_on_submit():
        attempted_employee = Employee.query.filter_by(email = form.email.data).first()
        if attempted_employee and attempted_employee.check_password_correction(form.password.data):
            session['employee'] = (attempted_employee)
            session['name'] = attempted_employee.name
            login_user(attempted_employee)
            flash(f'Success! You are logged in as: {attempted_employee.name}', category='success')
            return redirect(url_for('employee_actions'))
        else:
            flash('Invalid email or password! Please try again', category='danger')
    return render_template('login_employee.html', form = form)

@app.route('/signup_customer', methods = ['GET', 'POST'])
def signup_customer():
    form = signUpCustomer()
    if form.validate_on_submit():
        customer = Customer(customerID = form.customerID.data, name = form.name.data, 
                            address = form.address.data, branchID = form.branchID.data, phoneNumber = form.phoneNumber.data, 
                            email = form.email.data, password = form.password1.data)
        db.session.add(customer)
        db.session.commit()
        if form.errors == {}:
            flash(f'Success! You are signed up as: {customer.name}', category='success')
        return redirect(url_for('index'))
        
    if form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg, category='danger')
    return render_template('signup_customer.html', form = form)


@app.route('/login_customer', methods = ['GET', 'POST'])
def login_customer():
    form = loginCustomer()
    if form.validate_on_submit():
        attempted_customer = Customer.query.filter_by(email = form.email.data).first()
        if attempted_customer and attempted_customer.check_password_correction(form.password.data):
            session['customer'] = (attempted_customer)
            session['name'] = attempted_customer.name
            login_user(attempted_customer)
            flash(f'Success! You are logged in as: {attempted_customer.name}', category='success')
            return redirect(url_for('customer_actions'))
        else:
            flash('Invalid email or password! Please try again', category='danger')
    return render_template('login_customer.html', form = form)

@app.route('/manager_actions')
def manager_actions():
    return render_template('manager_actions.html')

@app.route('/manager_actions2', methods = ['GET', 'POST'])
def manager_actions2():
    form1 = viewBill()
    form2 = viewTruckStatus()
    if form1.validate_on_submit():
        print("hello")
        consignment = Consignment.query.filter_by(consignmentID = form1.consignmentID.data).first()
        session['consignment'] = consignment
        # if form1.errors != {}:
        #     for err_msg in form1.errors.values():
        #         flash(err_msg, category='danger')
        return redirect(url_for('view_bill'))
    if form2.validate_on_submit():
        truck = Truck.query.filter_by(truckID = form2.truckID.data).first()
        session['truck'] = truck
        # if form2.errors != {}:
        #     for err_msg in form2.errors.values():
        #         flash(err_msg, category='danger')
        return redirect(url_for('view_truck_status'))
        
        
    return render_template('manager_actions2.html',form1 = form1, form2 = form2)

@app.route('/view_bill', methods = ['GET', 'POST'])
def view_bill():
    return render_template('view_bill.html')

@app.route('/view_truck_status')
def view_truck_status():
    return render_template('view_truck_status.html')

@app.route('/employee_actions')
def employee_actions():
    return render_template('employee_actions.html')

@app.route('/customer_actions')
def customer_actions():
    return render_template('customer_actions.html')

@app.route('/create_employee', methods = ['GET', 'POST'])
def create_employee():
    form = createEmployee()
    if form.validate_on_submit():
        employee = Employee(employeeID = form.employeeID.data, name = form.name.data,
                            address = form.address.data, phoneNumber = form.phoneNumber.data, 
                            branchID = form.branchID.data,
                            email = form.email.data, password = form.password1.data)
        Office.query.filter_by(officeID = form.branchID.data).first().numEmployees += 1
        db.session.add(employee)
        db.session.commit()
        if form.errors == {}:
            flash(f'Success! You successfully added employee as: {employee.name}', category='success')
        return redirect(url_for('manager_actions2'))
    if form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg, category='danger')
    
    return render_template('create_employee.html', form = form)

@app.route('/create_branch', methods = ['GET', 'POST'])
def create_branch():
    form = createOffice()
    if form.validate_on_submit():
        office = Office(officeID = form.officeID.data, address = form.address.data, 
                        phoneNumber = form.phoneNumber.data, numTrucks = 0, numEmployees = 0, 
                        volumeHandled = 0, revenue = 0, idleWaitingTime = 0, rate = form.rate.data)
        db.session.add(office)
        db.session.commit()
        if form.errors == {}:
            flash(f'Success! You successfully added Branch: {office.officeID}', category='success')
        return redirect(url_for('manager_actions2'))
    if form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg, category='danger')
    
    return render_template('create_branch.html', form = form)

@app.route('/add_truck', methods = ['GET', 'POST'])
def add_truck():
    form = addTruck()
    if form.validate_on_submit():
        truck = Truck(truckID = form.truckID.data, currentBranchID = form.currentBranchID.data)
        Office.query.filter_by(officeID = form.currentBranchID.data).first().numTrucks += 1
        db.session.add(truck)
        db.session.commit()
        if form.errors == {}:
            flash(f'Success! You successfully added Truck: {truck.truckID}', category='success')
        return redirect(url_for('manager_actions2'))
    if form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg, category='danger')    
    return render_template('add_truck.html', form = form)

@app.route('/view_branch_truck_details', methods = ['GET', 'POST'])
def view_branch_truck_details():
    trucks = Truck.query.filter_by(currentBranchID = session['employee'].branchID).all()
    return render_template('view_branch_truck_details.html', trucks = trucks)

@app.route('/view_branch_consignment_details', methods = ['GET', 'POST'])
def view_branch_consignment_details():
    sent = Consignment.query.filter_by(senderID = session['employee'].branchID).all()
    received = Consignment.query.filter_by(receiverID = session['employee'].branchID).all()
    return render_template('view_branch_consignment_details.html', sent = sent, received = received)

@app.route('/view_branch_customer_details', methods = ['GET', 'POST'])
def view_branch_customer_details():
    customers = Customer.query.filter_by(branchID = session['employee'].branchID).all()
    return render_template('view_branch_customer_details.html', customers = customers)

@app.route('/place_order', methods = ['GET', 'POST'])
def place_order():
    form = placeOrder()
    if form.validate_on_submit():
        destinationofficeID = Customer.query.filter_by(customerID = form.receiverID.data).first().branchID
        destinationAddr = Customer.query.filter_by(customerID = form.receiverID.data).first().address
        sourceofficeID = Customer.query.filter_by(customerID = form.senderID.data).first().branchID
        sourceAddr = Customer.query.filter_by(customerID = form.senderID.data).first().address
        consignment = Consignment(consignmentID = form.consignmentID.data, senderID = form.senderID.data,
                                  receiverID = form.receiverID.data,destinationOfficeID = destinationofficeID, 
                                  destinationAddress = destinationAddr, sourceAddress = sourceAddr, 
                                  sourceOfficeID = sourceofficeID, volume = form.volume.data)
        sourceoffice = Office.query.filter_by(officeID = sourceofficeID).first()
        consignment.revenue = consignment.volume * sourceoffice.rate
        destinationoffice = Office.query.filter_by(officeID = destinationofficeID).first()
        sourceoffice.orders.append(consignment)
        db.session.add(consignment)
        sender = Customer.query.filter_by(customerID = form.senderID.data).first()
        sender.consignments += ("S"+str(consignment.consignmentID))
        receiver = Customer.query.filter_by(customerID = form.receiverID.data).first()
        receiver.consignments += ("R"+str(consignment.consignmentID))
        sourceoffice.orders.append(consignment)
        sourceoffice.total_orders += ("S"+str(consignment.consignmentID))
        destinationoffice.total_orders += ("R"+str(consignment.consignmentID))
        sourceoffice.volumeHandled += form.volume.data
        # truck = Truck.query.filter_by(currentBranchID = sourceoffice) and Truck.query.filter_by(status = "idle").first()
        while sourceoffice.volumeHandled >= 500:
            truck = Truck.query.filter_by(currentBranchID = sourceofficeID).first()
            if truck:
                current_vol = 0
                for order in sourceoffice.orders:
                    current_vol += order.volume
                    order.status = "delivered"
                    order.truckAssigned = truck.truckID
                    truck.numConsignments += 1
                    db.session.commit()
                    sourceoffice.orders.remove(order)
                    if current_vol>= 500:
                        sourceoffice.volumeHandled -= current_vol
                        truck.currentBranchID = destinationofficeID
                        break
            else:
                break                        
        db.session.commit()
        if form.errors == {}:
            flash(f'Success! You succressfully added Consignment: {consignment.consignmentID}', category='success')
        return redirect(url_for('customer_actions'))
    if form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg, category='danger')    
    return render_template('place_order.html', form = form)

@app.route('/customer_orders_history', methods = ['GET', 'POST'])
def customer_orders_history():
    sent_idx = []
    recv_idx = []
    for i in range(len(session['customer'].consignments)-1):
        if session['customer'].consignments[i] == "S":
            sent_idx.append(int(session['customer'].consignments[i+1]))
        elif session['customer'].consignments[i] == "R":
            recv_idx.append(int(session['customer'].consignments[i+1]))
    sent = []
    recv = []
    for i in sent_idx:
        sent.append(Consignment.query.filter_by(consignmentID = i).first())
    for i in recv_idx:
        recv.append(Consignment.query.filter_by(consignmentID = i).first())
    return render_template('customer_orders_history.html', sent = sent, recv = recv)