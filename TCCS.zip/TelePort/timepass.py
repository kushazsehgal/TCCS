class val:
    a = 1
    def __init__(self,a):
        self.a = a
v = val(2)
l = []
l.append(v)
l[0].a = 3
l[0].a = 4
print(v.a)